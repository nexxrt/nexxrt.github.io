[Reflection.Assembly]::LoadFile($args[0])
[AppRun.Run]::App("C:\Windows\notepad.exe")
[AppRun.Run]::App($args[1])